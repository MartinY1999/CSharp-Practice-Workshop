﻿using System;

namespace Heroes
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
