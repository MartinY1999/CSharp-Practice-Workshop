﻿namespace Heroes
{
    public interface ICommand
    {
        void Execute();
    }
}
