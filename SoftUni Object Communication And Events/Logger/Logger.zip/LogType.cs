﻿using System;
using System.Collections.Generic;
using System.Text;

public enum LogType
{
    ATTACK,
    MAGIC,
    TARGET,
    ERROR,
    EVENT
}